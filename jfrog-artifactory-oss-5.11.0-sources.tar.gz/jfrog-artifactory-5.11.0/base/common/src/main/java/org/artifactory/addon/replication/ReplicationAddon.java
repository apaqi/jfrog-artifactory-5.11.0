/*
 *
 * Artifactory is a binaries repository manager.
 * Copyright (C) 2016 JFrog Ltd.
 *
 * Artifactory is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 * Artifactory is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Artifactory.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package org.artifactory.addon.replication;

import org.artifactory.addon.Addon;
import org.artifactory.addon.license.EdgeBlockedAddon;
import org.artifactory.addon.replication.event.ReplicationChannelListener;
import org.artifactory.addon.replication.event.ReplicationEventQueueWorkItem;
import org.artifactory.api.common.BasicStatusHolder;
import org.artifactory.api.rest.replication.ReplicationStatus;
import org.artifactory.descriptor.replication.LocalReplicationDescriptor;
import org.artifactory.descriptor.replication.RemoteReplicationDescriptor;
import org.artifactory.descriptor.replication.ReplicationBaseDescriptor;
import org.artifactory.descriptor.repo.RealRepoDescriptor;
import org.artifactory.repo.RepoPath;

import java.io.IOException;
import java.util.List;

/**
 * @author Noam Y. Tenne
 */
@EdgeBlockedAddon
public interface ReplicationAddon extends Addon, ReplicationChannelListener {

    //replication
    String PROP_REPLICATION_PREFIX = "artifactory.replication.";
    String PROP_REPLICATION_STARTED_SUFFIX = ".started";
    String PROP_REPLICATION_FINISHED_SUFFIX = ".finished";
    String PROP_REPLICATION_RESULT_SUFFIX = ".result";
    String TASK_MANUAL_DESCRIPTOR = "task_manual_settings";

    BasicStatusHolder performRemoteReplication(RemoteReplicationSettings settings) throws IOException;

    BasicStatusHolder performLocalReplication(LocalReplicationSettings settings) throws IOException;

    void scheduleImmediateLocalReplicationTask(LocalReplicationDescriptor replicationDescriptor, BasicStatusHolder statusHolder);

    void scheduleImmediateRemoteReplicationTask(RemoteReplicationDescriptor replicationDescriptor, BasicStatusHolder statusHolder);

    ReplicationStatus getReplicationStatus(RepoPath repoPath);

    void offerLocalReplicationDeploymentEvent(RepoPath repoPath, boolean isFile);

    void offerLocalReplicationMkDirEvent(RepoPath repoPath, boolean isFile);

    void offerLocalReplicationDeleteEvent(RepoPath repoPath, boolean isFile);

    void offerLocalReplicationPropertiesChangeEvent(RepoPath repoPath, boolean isFile);

    void validateTargetIsDifferentInstance(ReplicationBaseDescriptor descriptor, RealRepoDescriptor repoDescriptor) throws IOException;

    void validateTargetLicense(ReplicationBaseDescriptor descriptor, RealRepoDescriptor repoDescriptor, int numOfReplicationConfigured) throws IOException;

    /**
     * Check if license is HA (only HA license support multi-push). If license is non-HA, keep only one replication
     * within the list of replications
     *
     * @param pushReplications The list of replications to perform
     * @return BasicStatusHolder Status holder that aggregates messages.
     */
    BasicStatusHolder filterIfMultiPushIsNotAllowed(List<LocalReplicationDescriptor> pushReplications);

    /**
     * When a local replication is removed, or changes it's url call this method to get rid of it's (now) unused properties
     */
    void cleanupLocalReplicationProperties(LocalReplicationDescriptor replication);

    void handlePropagatedRemoteReplicationEvents(String originNode, ReplicationEventQueueWorkItem events);

    enum Overwrite {
        never, force
    }
}
