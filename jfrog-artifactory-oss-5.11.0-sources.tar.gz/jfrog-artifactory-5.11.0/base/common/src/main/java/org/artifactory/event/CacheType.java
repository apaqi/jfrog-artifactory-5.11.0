package org.artifactory.event;

public enum CacheType {
    ACL
}
