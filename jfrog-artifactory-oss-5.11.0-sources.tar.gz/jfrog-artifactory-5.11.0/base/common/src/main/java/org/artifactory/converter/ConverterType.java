package org.artifactory.converter;

/**
 * @author gidis
 */
public enum ConverterType {
    PRE_INIT,
    HOME_SYNC_FILES,
    HOME_FILES,
    POST_INIT
}