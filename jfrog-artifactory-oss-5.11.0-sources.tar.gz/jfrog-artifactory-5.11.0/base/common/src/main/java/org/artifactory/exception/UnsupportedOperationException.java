package org.artifactory.exception;

/**
 * @author Shay Bagants
 */
public class UnsupportedOperationException extends Exception {

    public UnsupportedOperationException(String message) {
        super(message);
    }
}
