package org.artifactory.addon.xray;

/**
 * @author Chen Keinan
 */
public interface XrayRepo {

    String getName();

    String getPkgType();

    String getType();
}
