package org.artifactory.addon.webstart;

/**
 * @author Shay Bagants
 */
public class KeyStoreNotFoundException extends Exception {

    public KeyStoreNotFoundException(String message) {
        super(message);
    }
}
