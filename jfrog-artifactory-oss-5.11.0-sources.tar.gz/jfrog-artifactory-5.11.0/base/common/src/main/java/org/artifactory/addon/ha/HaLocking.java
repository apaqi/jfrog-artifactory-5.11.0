package org.artifactory.addon.ha;

/**
 * @author Shay Bagants
 */
public interface HaLocking {
}
