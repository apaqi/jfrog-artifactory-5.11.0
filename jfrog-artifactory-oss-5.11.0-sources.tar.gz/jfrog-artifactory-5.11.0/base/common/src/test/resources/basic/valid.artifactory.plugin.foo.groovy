package basic

/**
 * @author Uriah Levy
 * Since 12/02/2018.
 */
class Foo {

}